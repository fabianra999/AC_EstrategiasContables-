<header>
    <a href="#">
        <h1><span>AC</span> Estrategias Contables y Financieras </h1>
    </a>
</header>


<nav class="navbar navbar-toggleable-md navbar-inverse">
    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavDropdown">
        <ul class="navbar-nav">
            <li class="nav-item active">
                <a class="nav-link" href="index.php">INICIO <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="quienes-somos.php">QUIÉNES SOMOS</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="servicios.php">SERVICIOS</a>
            </li>
           <!-- <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="servicios.php" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    SERVICIOS
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                    <a class="dropdown-item" href="servicios.php">SERVICIOS CONTABLES</a>
                </div>
            </li>-->
            <li class="nav-item">
                <a class="nav-link" href="contacto.php">CONTACTO</a>
            </li>
        </ul>
    </div>
</nav>