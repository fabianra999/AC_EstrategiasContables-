<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>AC Estrategias Contables y Financieras </title>


    <link rel="shortcut icon" href="components/favicon/favicon.ico" type="image/x-icon">
    <link rel="icon" href="components/favicon/favicon.ico" type="image/x-icon">

    <meta name="theme-color" content="#ffffff">

    <!-- styles -->
    <link rel="stylesheet" href="dist/libs/styles/libsMain.min.css">
    <link rel="stylesheet" href="dist/styles/screen.min.css">
    <!-- components -->

    <!-- bower:css -->
    <!-- endbower -->

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="components/html5shiv/html5shiv.min.js"></script>
    <script src="components/respond/respond.min.js"></script>
    <![endif]-->
</head>
