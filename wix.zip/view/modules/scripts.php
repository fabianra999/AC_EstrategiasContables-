<!-- Script -->

<!--Components-->
<script src="bower_components/jquery/dist/jquery.js"></script>
<script src="bower_components/bootstrap/dist/js/bootstrap.js"></script>
<script src="bower_components/gsap/src/minified/TweenMax.min.js"></script>
<script src="bower_components/gsap/src/minified/TimelineMax.min.js"></script>
<script src="bower_components/scrollmagic/scrollmagic/minified/ScrollMagic.min.js"></script>
<script src="bower_components/scrollmagic/scrollmagic/minified/plugins/animation.gsap.min.js"></script>
<script src="bower_components/scrollmagic/scrollmagic/minified/plugins/debug.addIndicators.min.js"></script>
<!--javaScript-->
<script src="dist/scripts/javaScript/scriptJs.min.js"></script>
<!--typeScript-->
<script src="dist/scripts/tipeScript/scriptTs.min.js"></script>


<!-- bower:js -->

<!-- endbower -->
