<!-- Script -->

<!--Components-->
<script src="bower_components/jquery/dist/jquery.js"></script>
<script src="bower_components/bootstrap/dist/js/bootstrap.js"></script>
<!--javaScript-->
<script src="dist/scripts/javaScript/scriptJs.min.js"></script>
<!--typeScript-->
<script src="dist/scripts/tipeScript/scriptTs.min.js"></script>


<!-- bower:js -->

<!-- endbower -->
