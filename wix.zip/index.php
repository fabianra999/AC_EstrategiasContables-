<!DOCTYPE html>
<html>
	<!--head-->
	<?php include 'view/modules/head.php';?>
    <body>
		<!--header-->
		<?php include 'view/modules/header.php';?>

        <?php include 'view/layouts/home.php';?>
        <!--footer-->
        <?php include 'view/modules/footer.php';?>
        <!--scripts-->
        <?php include 'view/modules/scripts.php';?>
	</body>
</html>




