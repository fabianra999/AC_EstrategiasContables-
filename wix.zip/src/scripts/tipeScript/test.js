var element = document.getElementById("menuMenu").slice();
console.dir(element);
