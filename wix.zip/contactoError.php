<!DOCTYPE html>
<html>
<!--head-->
<?php include 'view/modules/head.php'; ?>
<body>
<!--header-->
<?php include 'view/modules/header.php'; ?>

<br>
<div class="stateMessage">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="alert alert-danger" role="alert">
                    EL mensaje no pude ser enviado intente de nuevo.
                </div>
            </div>
        </div>
    </div>
</div>
<br>
<?php include 'view/layouts/contacto.php'; ?>

<!--footer-->
<?php include 'view/modules/footer.php'; ?>
<!--scripts-->
<?php include 'view/modules/scripts.php'; ?>
</body>
</html>




