<?php
$destino = 'fabianra999@gmail.com';
$name =  $_POST['fName'];
$email =  $_POST['fEmail'];
$asunto =  $_POST['fAsunto'];
$mensage =  $_POST['fMensaje'];

$email_subject = "Contacto web Paola.com:  $name";
$email_body = "Has recibido un mensaje nuevo. "." Aquí están los detalles: " ."\nNombre: " . $name . "\nCorreo: " . $email . "\nMensage: " . "\nAsunto: " . $asunto;



mail($destino, $email_subject, utf8_decode($email_body), $email_body);

header('location:index.php');


/*$result = mail($destino, $email_subject);
if(!$result) {
    print "<p class='Error'>Problem in Sending Mail.</p>";
    echo "Error";
    header("Location:index.php");
} else {
    print "<p class='success'>Contact Mail Sent.</p>";
    echo "Success";
    header("Location:index.php");
}*/

?>"&gt;